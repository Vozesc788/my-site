﻿export default function HomePage() {
  return (
    <div className="container">
      <header className="navbar">
        <a href="#" className="logo">NextApp</a>
        <nav>
          <ul className="nav-links">
            <li><a href="#features">Особливості</a></li>
            <li><a href="#about">Про проект</a></li>
            <li><a href="#contact">Контакти</a></li>
          </ul>
        </nav>
      </header>

      <section className="hero">
        <h1>Створюйте сучасні веб-додатки з <span>Next.js 16</span></h1>
        <p>
          Швидкий, легкий та продуктивний шаблон Landing Page з App Router, темною темою та чистим CSS без зайвих залежностей.
        </p>
        <a href="#features" className="cta-button">Розпочати роботу</a>
      </section>

      <section id="features" className="features">
        <h2 className="section-title">Основні переваги</h2>
        <div className="grid">
          <div className="card">
            <h3>App Router</h3>
            <p>Сучасна архітектура маршрутизації Next.js для максимальної швидкості та зручності розробки.</p>
          </div>
          <div className="card">
            <h3>Чистий JavaScript</h3>
            <p>Без складних налаштувань TypeScript - лише зрозумілий, чистий та легкий JS код.</p>
          </div>
          <div className="card">
            <h3>Темна тема</h3>
            <p>Сучасний стильний дизайн у темних тонах з акцентними кольорами, приємний для очей.</p>
          </div>
        </div>
      </section>

      <footer id="contact" className="footer">
        <p>© 2026 NextApp. Усі права захищено.</p>
      </footer>
    </div>
  );
}
