﻿import './globals.css';

export const metadata = {
  title: 'Next.js 16 Landing Page',
  description: 'Мінімалістичний лендінг на Next.js v16 у темній темі',
};

export default function RootLayout({ children }) {
  return (
    <html lang="uk">
      <body>{children}</body>
    </html>
  );
}
