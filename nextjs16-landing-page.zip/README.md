﻿# Next.js 16 Dark Landing Page

Мінімальний проект лендінгу.

## Як запустити:
1. npm install
2. npm run dev
